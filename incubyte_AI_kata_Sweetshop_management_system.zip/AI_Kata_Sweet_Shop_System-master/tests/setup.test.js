/**
 * Setup verification test
 * This test ensures our testing framework is working correctly
 */

describe('Setup Verification', () => {
  test('Jest is working correctly', () => {
    expect(true).toBe(true);
  });

  test('Basic math operations work', () => {
    expect(2 + 2).toBe(4);
  });
});
